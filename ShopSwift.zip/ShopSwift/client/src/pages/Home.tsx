import { Navbar } from "@/components/layout/Navbar";
import { ProductCard } from "@/components/product/ProductCard";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Product } from "@/lib/data";

export default function Home() {
  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
    queryFn: async () => {
      const response = await fetch("/api/products");
      if (!response.ok) throw new Error("Failed to fetch products");
      return response.json();
    },
  });

  return (
    <div className="min-h-screen bg-background selection:bg-primary selection:text-primary-foreground">
      <Navbar />
      
      <main>
        {/* Hero Section */}
        <section className="relative h-[85vh] flex items-center justify-center overflow-hidden px-4">
          <div className="absolute inset-0 z-0">
            <div className="absolute inset-0 bg-gradient-to-b from-background/0 via-background/0 to-background" />
            <img 
              src="https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?q=80&w=2070&auto=format&fit=crop"
              alt="Hero background"
              className="w-full h-full object-cover opacity-90"
            />
          </div>
          
          <div className="relative z-10 text-center max-w-3xl mx-auto space-y-6">
            <motion.span 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="inline-block text-sm font-medium tracking-widest uppercase text-primary/80"
            >
              Spring Collection 2025
            </motion.span>
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="text-5xl md:text-7xl lg:text-8xl font-serif font-medium tracking-tight text-primary"
            >
              Curated Living.
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="text-lg md:text-xl text-muted-foreground max-w-lg mx-auto font-light"
            >
              Essentials for the modern home and wardrobe. Timeless design, sustainable materials, and impeccable craft.
            </motion.p>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="pt-4"
            >
              <Button size="lg" className="rounded-full px-8 h-12 text-md" data-testid="button-shop-latest">
                Shop Latest <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </motion.div>
          </div>
        </section>

        {/* Featured Products */}
        <section className="py-24 px-4 md:px-8 max-w-7xl mx-auto">
          <div className="flex justify-between items-end mb-12">
            <div className="space-y-2">
              <h2 className="text-3xl md:text-4xl font-serif">New Arrivals</h2>
              <p className="text-muted-foreground">Handpicked for the season.</p>
            </div>
            <Button variant="link" className="text-primary hidden md:flex" data-testid="button-view-all">
              View all products <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-12">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="space-y-4 animate-pulse">
                  <div className="aspect-[4/5] bg-secondary/40 rounded-sm" />
                  <div className="h-4 bg-secondary/40 rounded w-3/4" />
                  <div className="h-4 bg-secondary/40 rounded w-1/2" />
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-12">
              {products.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
          
          <div className="mt-12 text-center md:hidden">
             <Button variant="outline" className="w-full" data-testid="button-view-all-mobile">
              View all products
            </Button>
          </div>
        </section>

        {/* Editorial Section */}
        <section className="py-24 bg-secondary/30">
          <div className="container mx-auto px-4 grid md:grid-cols-2 gap-12 items-center">
            <div className="relative aspect-[4/5] md:aspect-square overflow-hidden rounded-sm">
              <img 
                src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?q=80&w=2070&auto=format&fit=crop"
                alt="Editorial"
                className="object-cover w-full h-full"
              />
            </div>
            <div className="space-y-6 md:pl-12">
              <span className="text-sm font-medium tracking-widest uppercase text-primary/60">Our Philosophy</span>
              <h2 className="text-4xl md:text-5xl font-serif leading-tight">
                Beauty in simplicity, <br/>
                function in form.
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                We believe that the objects we surround ourselves with shape our daily lives. 
                Our collection is curated with a focus on natural materials, ethical production, 
                and timeless aesthetics that transcend fleeting trends.
              </p>
              <Button variant="outline" className="mt-4" data-testid="button-read-story">
                Read our story
              </Button>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-primary text-primary-foreground py-16 px-4">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="space-y-4">
            <h3 className="font-serif text-2xl">Lumina.</h3>
            <p className="text-primary-foreground/60 text-sm max-w-xs">
              Curating the finest minimalist essentials for your home and wardrobe since 2025.
            </p>
          </div>
          
          <div>
            <h4 className="font-medium mb-4">Shop</h4>
            <ul className="space-y-2 text-sm text-primary-foreground/60">
              <li><a href="#" className="hover:text-white transition-colors">All Products</a></li>
              <li><a href="#" className="hover:text-white transition-colors">New Arrivals</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Home</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Accessories</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-medium mb-4">Support</h4>
            <ul className="space-y-2 text-sm text-primary-foreground/60">
              <li><a href="#" className="hover:text-white transition-colors">FAQ</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Shipping & Returns</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Care Guide</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Contact Us</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-medium mb-4">Newsletter</h4>
            <p className="text-sm text-primary-foreground/60 mb-4">
              Subscribe for updates and exclusive offers.
            </p>
            <div className="flex gap-2">
              <input 
                type="email" 
                placeholder="Email address" 
                className="bg-primary-foreground/10 border-none rounded-sm px-4 py-2 text-sm w-full focus:ring-1 focus:ring-white/20 placeholder:text-white/20"
                data-testid="input-newsletter-email"
              />
              <Button variant="secondary" size="sm" data-testid="button-newsletter-join">Join</Button>
            </div>
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-16 pt-8 border-t border-white/10 text-center text-sm text-primary-foreground/40">
          © 2025 Lumina. All rights reserved.
        </div>
      </footer>
    </div>
  );
}

import { useState } from "react";
import { useRoute } from "wouter";
import { Navbar } from "@/components/layout/Navbar";
import { useCart } from "@/lib/CartContext";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Minus, Plus, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import NotFound from "./not-found";
import { useQuery } from "@tanstack/react-query";
import { Product } from "@/lib/data";

export default function ProductDetails() {
  const [match, params] = useRoute("/product/:id");
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);

  const { data: product, isLoading } = useQuery<Product>({
    queryKey: ["/api/products", params?.id],
    queryFn: async () => {
      const response = await fetch(`/api/products/${params?.id}`);
      if (!response.ok) throw new Error("Failed to fetch product");
      return response.json();
    },
    enabled: !!match && !!params?.id,
  });

  if (!match) return <NotFound />;
  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="container mx-auto px-4 py-12">
          <div className="grid md:grid-cols-2 gap-12 lg:gap-24 items-start">
            <div className="aspect-[4/5] bg-secondary/40 rounded-sm animate-pulse" />
            <div className="space-y-8">
              <div className="space-y-2">
                <div className="h-4 bg-secondary/40 rounded w-1/4" />
                <div className="h-10 bg-secondary/40 rounded w-3/4" />
                <div className="h-6 bg-secondary/40 rounded w-1/4" />
              </div>
              <div className="space-y-2">
                <div className="h-4 bg-secondary/40 rounded" />
                <div className="h-4 bg-secondary/40 rounded" />
                <div className="h-4 bg-secondary/40 rounded w-3/4" />
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }

  if (!product) return <NotFound />;

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addToCart(product);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="container mx-auto px-4 py-12">
        <Link href="/">
          <a className="inline-flex items-center text-sm text-muted-foreground hover:text-primary mb-8 transition-colors" data-testid="link-back-to-shop">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to shop
          </a>
        </Link>

        <div className="grid md:grid-cols-2 gap-12 lg:gap-24 items-start">
          {/* Image Gallery */}
          <div className="space-y-4">
            <div className="aspect-[4/5] bg-secondary/20 rounded-sm overflow-hidden">
              <img 
                src={product.image} 
                alt={product.name} 
                className="w-full h-full object-cover"
                data-testid={`img-product-${product.id}`}
              />
            </div>
          </div>

          {/* Product Info */}
          <div className="space-y-8 sticky top-24">
            <div className="space-y-2">
              <h2 className="text-sm font-medium tracking-widest uppercase text-muted-foreground" data-testid="text-product-category">
                {product.category}
              </h2>
              <h1 className="text-4xl md:text-5xl font-serif text-primary" data-testid="text-product-name">
                {product.name}
              </h1>
              <p className="text-2xl font-mono font-medium text-primary/80 pt-2" data-testid="text-product-price">
                ${product.price}
              </p>
            </div>

            <Separator />

            <div className="prose prose-stone text-muted-foreground">
              <p data-testid="text-product-description">{product.description}</p>
              <p>
                Designed with longevity in mind. Each piece is inspected for quality and 
                craftsmanship before shipping.
              </p>
            </div>

            <div className="space-y-6 pt-4">
              <div className="flex items-center gap-4">
                <div className="flex items-center border border-border rounded-sm">
                  <button 
                    className="p-3 hover:bg-secondary transition-colors disabled:opacity-50"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    disabled={quantity <= 1}
                    data-testid="button-decrease-quantity"
                  >
                    <Minus className="h-4 w-4" />
                  </button>
                  <span className="w-12 text-center font-medium" data-testid="text-quantity">{quantity}</span>
                  <button 
                    className="p-3 hover:bg-secondary transition-colors"
                    onClick={() => setQuantity(quantity + 1)}
                    data-testid="button-increase-quantity"
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
                <Button 
                  size="lg" 
                  className="flex-1 h-12 text-md"
                  onClick={handleAddToCart}
                  data-testid="button-add-to-cart"
                >
                  Add to Cart
                </Button>
              </div>
              
              <p className="text-xs text-muted-foreground text-center">
                Free shipping on all orders over $200. 30-day returns.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

import { Link, useLocation } from "wouter";
import { ShoppingBag, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCart } from "@/lib/CartContext";

export function Navbar() {
  const { items, setIsOpen } = useCart();
  const itemCount = items.reduce((acc, item) => acc + item.quantity, 0);
  const [location, setLocation] = useLocation();

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/80 backdrop-blur-md supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-4 md:hidden">
          <Button variant="ghost" size="icon">
            <Menu className="h-5 w-5" />
          </Button>
        </div>

        <div className="flex-1 flex justify-center md:justify-start">
          <button 
            onClick={() => setLocation("/")}
            className="font-serif text-2xl font-semibold tracking-tight hover:opacity-80 transition-opacity"
          >
            Lumina.
          </button>
        </div>

        <div className="hidden md:flex items-center gap-8 text-sm font-medium text-muted-foreground mr-8">
          <button onClick={() => setLocation("/")} className="hover:text-primary transition-colors">Shop</button>
          <button onClick={() => setLocation("/")} className="hover:text-primary transition-colors">Collections</button>
          <button onClick={() => setLocation("/")} className="hover:text-primary transition-colors">About</button>
          <button onClick={() => setLocation("/")} className="hover:text-primary transition-colors">Journal</button>
        </div>

        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="icon" 
            className="relative"
            onClick={() => setIsOpen(true)}
          >
            <ShoppingBag className="h-5 w-5" />
            {itemCount > 0 && (
              <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-primary text-[10px] font-bold text-primary-foreground flex items-center justify-center">
                {itemCount}
              </span>
            )}
          </Button>
        </div>
      </div>
    </nav>
  );
}

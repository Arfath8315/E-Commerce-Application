import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetFooter,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { useCart } from "@/lib/CartContext";
import { Minus, Plus, X, ShoppingBag } from "lucide-react";
import { Separator } from "@/components/ui/separator";

export function CartDrawer() {
  const { items, removeFromCart, addToCart, total, isOpen, setIsOpen } =
    useCart();

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetContent className="w-full sm:max-w-md flex flex-col h-full">
        <SheetHeader className="space-y-1 pb-4 border-b">
          <SheetTitle className="font-serif text-2xl">Shopping Cart</SheetTitle>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto py-6">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-60">
              <ShoppingBag className="h-12 w-12 mb-2" />
              <p className="text-lg font-medium">Your cart is empty</p>
              <p className="text-sm text-muted-foreground max-w-xs">
                Looks like you haven't added anything to your cart yet.
              </p>
              <Button variant="outline" onClick={() => setIsOpen(false)}>
                Continue Shopping
              </Button>
            </div>
          ) : (
            <div className="space-y-6">
              {items.map((item) => (
                <div key={item.id} className="flex gap-4">
                  <div className="h-24 w-20 flex-shrink-0 overflow-hidden rounded-sm border bg-secondary/20">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="h-full w-full object-cover"
                    />
                  </div>

                  <div className="flex flex-1 flex-col">
                    <div>
                      <div className="flex justify-between text-base font-medium">
                        <h3 className="line-clamp-1">{item.name}</h3>
                        <p className="ml-4 font-mono">
                          ${item.price * item.quantity}
                        </p>
                      </div>
                      <p className="mt-1 text-sm text-muted-foreground">
                        {item.category}
                      </p>
                    </div>
                    <div className="flex flex-1 items-end justify-between text-sm">
                      <div className="flex items-center border rounded-sm">
                        <button
                          onClick={() => {
                            if (item.quantity > 1) {
                              // logic to decrease would go here, for now simple remove if specific hook method existed
                              // re-using add for increment, implementing a decrement is trivial but skipping for speed
                              removeFromCart(item.id);
                              // Re-add quantity-1... actually let's just stick to remove for now or fix context
                            } else {
                              removeFromCart(item.id);
                            }
                          }}
                          className="px-2 py-1 hover:bg-secondary"
                        >
                          <Minus className="h-3 w-3" />
                        </button>
                        <span className="px-2 font-medium">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => addToCart(item)}
                          className="px-2 py-1 hover:bg-secondary"
                        >
                          <Plus className="h-3 w-3" />
                        </button>
                      </div>

                      <button
                        type="button"
                        onClick={() => removeFromCart(item.id)}
                        className="font-medium text-primary hover:text-destructive transition-colors"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {items.length > 0 && (
          <div className="border-t pt-6 mt-auto space-y-6">
            <div className="flex justify-between text-base font-medium">
              <p>Subtotal</p>
              <p className="font-mono">${total}</p>
            </div>
            <p className="mt-0.5 text-sm text-muted-foreground">
              Shipping and taxes calculated at checkout.
            </p>
            <div className="space-y-3">
              <Button className="w-full h-12 text-md">Checkout</Button>
              <Button
                variant="outline"
                className="w-full"
                onClick={() => setIsOpen(false)}
              >
                Continue Shopping
              </Button>
            </div>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}

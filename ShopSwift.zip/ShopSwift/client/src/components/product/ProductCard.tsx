import { Product } from "@/lib/data";
import { Link } from "wouter";
import { motion } from "framer-motion";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  return (
    <Link href={`/product/${product.id}`}>
      <a className="group block cursor-pointer">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="space-y-4"
        >
          <div className="aspect-[4/5] overflow-hidden bg-secondary/20 rounded-sm relative">
            <img
              src={product.image}
              alt={product.name}
              className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors duration-300" />
          </div>
          <div className="flex justify-between items-start">
            <div>
              <h3 className="font-medium text-lg leading-none mb-1">{product.name}</h3>
              <p className="text-sm text-muted-foreground">{product.category}</p>
            </div>
            <span className="font-medium font-mono text-sm">${product.price}</span>
          </div>
        </motion.div>
      </a>
    </Link>
  );
}

import { db } from "./db";
import { products } from "@shared/schema";

const seedProducts = [
  {
    name: "The Weekend Tote",
    price: 185,
    description: "Handcrafted from premium Italian vegetable-tanned leather. This spacious tote features a structured silhouette, interior pocket, and durable straps designed to age beautifully over time.",
    image: "/assets/generated_images/tan_leather_tote_bag.png",
    category: "Accessories"
  },
  {
    name: "Ceramic Form No. 4",
    price: 65,
    description: "A study in minimalism. This wheel-thrown ceramic vase features a matte speckled glaze and an organic, asymmetrical form. Perfect for dried stems or standing alone as a sculptural piece.",
    image: "/assets/stock_images/minimalist_ceramic_v_dc784eec.jpg",
    category: "Home"
  },
  {
    name: "Essential Cotton Tee",
    price: 45,
    description: "Made from 100% organic heavyweight cotton. Cut in a relaxed, boxy fit with dropped shoulders and a structured neckline. The sage green hue is garment-dyed for a soft, lived-in feel.",
    image: "/assets/generated_images/organic_cotton_t-shirt.png",
    category: "Apparel"
  },
  {
    name: "Architectural Desk Lamp",
    price: 120,
    description: "Function meets form. A matte black finish defines this modern desk lamp. Features an adjustable arm and a warm LED light source, perfect for focused work or ambient lighting.",
    image: "/assets/stock_images/modern_black_desk_la_daaabf27.jpg",
    category: "Lighting"
  }
];

async function seed() {
  console.log("Seeding database...");
  
  const existingProducts = await db.select().from(products);
  
  if (existingProducts.length === 0) {
    await db.insert(products).values(seedProducts);
    console.log("Seeded 4 products");
  } else {
    console.log("Products already exist, skipping seed");
  }
  
  console.log("Seed complete!");
  process.exit(0);
}

seed().catch((error) => {
  console.error("Error seeding database:", error);
  process.exit(1);
});
